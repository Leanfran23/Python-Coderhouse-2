from setuptools import setup

setup(
    name = "clientes",
    version = "1.0",
    description = "Actualiza datos del cliente y dice que producto compro",
    author = "Leandro Franco",
    author_email = "leafranco90@gmail.com",
    packages = ["paquete"]
)
